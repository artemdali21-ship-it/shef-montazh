# КАРТА НАВИГАЦИИ ШЕФ-МОНТАЖ

## ОСНОВНЫЕ ПЕРЕХОДЫ

### Начальный экран (/)
- ✅슬래이더 с 3 слайдами
- ✅ Кнопка "Далее" → последний слайд → /role-select
- ✅ Кнопка "Пропустить" → /role-select

### Выбор роли (/role-select)
- ✅ 3 карточки: Заказчик, Исполнитель, Шеф-монтажник
- ✅ Каждая карточка → /login

### Вход в систему (/login)
- ✅ Форма входа
- ✅ "Вход" → /feed (основной экран)
- ✅ "Забыли пароль?" → /forgot-password
- ✅ "Регистрация" → /register

### Регистрация (/register)
- ✅ Форма регистрации
- ✅ "Регистрация" → /feed ИЛИ /dashboard

### Проверка номера (/verify-phone)
- ✅ Ввод кода
- ✅ "Подтвердить" → /profile-setup

### Настройка профиля (/profile-setup)
- ✅ Форма профиля
- ✅ "Сохранить" → /feed

## ОСНОВНЫЕ РАЗДЕЛЫ (С нижней навигацией)

### Лента смен (/feed)
- ✅ JobFeedScreen с BottomNavigation
- ✅ Карточки смен - клик → /job/[id]
- ✅ Нижняя навигация:
  - "Смены" (активна) → /feed
  - "Заявки" → /applications
  - "Профиль" → /profile

### Мои заявки (/applications) - ТА же что /my-applications
- ✅ MyApplicationsScreen с BottomNavigation
- ✅ Карточки заявок - клик → детали
- ✅ Нижняя навигация:
  - "Смены" → /feed
  - "Заявки" (активна) → /applications
  - "Профиль" → /profile

### Профиль (/profile)
- ✅ ProfileScreen с BottomNavigation
- ✅ Меню профиля
- ✅ Нижняя навигация:
  - "Смены" → /feed
  - "Заявки" → /applications
  - "Профиль" (активна) → /profile

### Детали смены (/job/[id])
- ✅ JobDetailsScreen
- ✅ Кнопки действий
- ✅ Кнопка "Назад" → /feed ИЛИ /applications (зависит от источника)

## МОДАЛЬНЫЕ/ВСПОМОГАТЕЛЬНЫЕ ЭКРАНЫ

### Подтверждение заявки
- ✅ ApplicationConfirmationScreen
- ✅ "Вернуться к поиску" → /feed
- ✅ "К моим заявкам" → /my-applications (ОШИБКА: должно быть /applications)

### Активная смена (/shift)
- ✅ ActiveShiftScreen
- ✅ Мониторинг в реальном времени
- ✅ "Завершить смену" → /rating

### Рейтинг (/rating)
- ✅ RatingReviewScreen
- ✅ "Отправить отзыв" → /feed

### Расчет платежа (/payment-details)
- ✅ PaymentDetailScreen
- ✅ "Подтвердить" → ?

## НАСТРОЙКИ (/settings)
- ✅ /settings - главная
- ✅ /settings/edit-profile - редактирование
- ✅ /settings/security - безопасность
- ✅ /settings/payment - платежи
- ✅ /settings/notifications - уведомления
- ✅ /settings/location - локация
- ✅ /settings/about - о приложении
- ✅ /settings/help - помощь

## ПРАВОВЫЕ СТРАНИЦЫ
- ✅ /legal/terms - условия использования
- ✅ /legal/privacy - политика конфиденциальности
- ✅ /legal/offer - публичный договор

## ПРОБЛЕМЫ И ОШИБКИ

### ❌ КРИТИЧЕСКИЕ
1. `/my-applications` → должно быть `/applications` (в ApplicationConfirmationScreen.tsx строка 519)
2. `/shift-details` → НЕ существует как отдельный маршрут
3. `/notifications` - линк в Header.tsx но нет маршрута
4. `/forgot-password` - линк в LoginScreen.tsx но нет маршрута

### ⚠️ ПРЕДУПРЕЖДЕНИЯ
1. `/shef-dashboard` - существует но не связан с основной навигацией
2. `/monitoring` - существует но не связан
3. `/create-shift` - существует но не доступен из интерфейса
4. Некоторые экраны не используют Bottom Navigation (должны!)

### 📝 ПРОВЕРЕНО
- ✅ Все переходы между основными разделами (/feed, /applications, /profile) работают
- ✅ Bottom Navigation активна на всех основных экранах
- ✅ Header back button работает
- ✅ Картинки загружаются правильно
