import JobDetailsScreen from '@/components/JobDetailsScreen'

export default function JobDetailsPage() {
  return <JobDetailsScreen />
}
