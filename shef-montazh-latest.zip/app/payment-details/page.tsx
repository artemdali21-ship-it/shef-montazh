'use client';

import PaymentDetailScreen from '@/components/PaymentDetailScreen';

export default function PaymentDetailsPage() {
  return <PaymentDetailScreen />;
}
