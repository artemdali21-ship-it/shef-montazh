import ApplicationConfirmationScreen from '@/components/ApplicationConfirmationScreen'

export default function ApplicationPage() {
  return <ApplicationConfirmationScreen />
}
