import ClientProfile from "@/components/profile/ClientProfile";

export default function ClientProfilePage() {
  return <ClientProfile />;
}
