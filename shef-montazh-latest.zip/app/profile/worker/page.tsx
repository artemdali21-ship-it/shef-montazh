import WorkerProfile from "@/components/profile/WorkerProfile";

export default function WorkerProfilePage() {
  return <WorkerProfile />;
}
