import ShiftMonitoringScreen from '@/components/ShiftMonitoringScreen';

export default function MonitoringPage() {
  return <ShiftMonitoringScreen />;
}
