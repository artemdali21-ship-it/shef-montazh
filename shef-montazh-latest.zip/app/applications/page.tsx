'use client'

import MyApplicationsScreen from '@/components/MyApplicationsScreen'

export default function ApplicationsPage() {
  return <MyApplicationsScreen />
}
