import ActiveShiftScreen from '@/components/ActiveShiftScreen'

export default function ShiftPage() {
  return <ActiveShiftScreen />
}
