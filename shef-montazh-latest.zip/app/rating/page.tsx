'use client';

import RatingReviewScreen from '@/components/RatingReviewScreen';

export default function RatingPage() {
  return <RatingReviewScreen />;
}
